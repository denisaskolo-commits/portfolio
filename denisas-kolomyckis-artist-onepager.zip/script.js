// Artistic one-pager logic
const $ = (s, el=document) => el.querySelector(s);
const $$ = (s, el=document) => [...el.querySelectorAll(s)];

const state = {
  mood: "default",
  tag: "All",
  q: "",
  data: null,
  works: [],
};

async function loadJSON(path){
  const res = await fetch(path, { cache: "no-store" });
  if(!res.ok) throw new Error(`Failed to load ${path}`);
  return res.json();
}

// ---------------- Grain canvas ----------------
const grain = $("#grain");
const gctx = grain.getContext("2d");

function sizeGrain(){
  grain.width = window.innerWidth;
  grain.height = window.innerHeight;
}
window.addEventListener("resize", sizeGrain);
sizeGrain();

function drawGrain(){
  const w = grain.width, h = grain.height;
  const img = gctx.createImageData(w, h);
  // sparse random pixels (fast)
  for(let i=0;i<img.data.length;i+=4*5){
    const v = (Math.random()*255)|0;
    img.data[i] = v;
    img.data[i+1] = v;
    img.data[i+2] = v;
    img.data[i+3] = 22 + (Math.random()*38)|0;
  }
  gctx.putImageData(img, 0, 0);
  requestAnimationFrame(drawGrain);
}
requestAnimationFrame(drawGrain);

// ---------------- Mood switch ----------------
function cycleMood(){
  const moods = ["default","warm","acid","ice"];
  const cur = document.documentElement.dataset.mood || "default";
  const idx = moods.indexOf(cur);
  const next = moods[(idx+1)%moods.length];
  if(next === "default") delete document.documentElement.dataset.mood;
  else document.documentElement.dataset.mood = next;
  localStorage.setItem("mood", next);
}
function initMood(){
  const saved = localStorage.getItem("mood");
  if(saved && saved !== "default") document.documentElement.dataset.mood = saved;
}

// ---------------- Practice rendering ----------------
function renderPractice(){
  const {artist} = state.data;
  $("#artistName").textContent = artist.name;
  $("#artistName2").textContent = artist.name;
  $("#artistRole").textContent = (artist.roles || []).join(" / ");
  $("#emailLink").textContent = artist.email;
  $("#emailLink").href = `mailto:${artist.email}`;
  $("#igLink").href = artist.instagram || "#";

  const st = $("#statement");
  st.innerHTML = "";
  (artist.statement || []).forEach(p => {
    const el = document.createElement("p");
    el.textContent = p;
    st.appendChild(el);
  });

  const cards = $("#practiceCards");
  cards.innerHTML = "";
  (artist.practice || []).forEach(p => {
    const d = document.createElement("article");
    d.className = "card";
    d.innerHTML = `<h3>${p.label}</h3><p>${p.text}</p>`;
    cards.appendChild(d);
  });

  $("#pressNote").textContent = artist.press_note || "";
  $("#year").textContent = new Date().getFullYear();

  const m = state.data.magnet || {};
  $("#magnetHead").textContent = m.headline || "Beat Tetris to unlock the magnet.";
  $("#magnetSub").textContent = m.subhead || "";
}

// ---------------- Works: chips + masonry ----------------
function uniq(arr){ return [...new Set(arr)]; }

function buildChips(){
  const chipWrap = $("#chips");
  const tags = uniq(["All", ...state.works.flatMap(w => w.tags || [])]);
  chipWrap.innerHTML = "";
  tags.forEach(t => {
    const b = document.createElement("button");
    b.className = "chip";
    b.type = "button";
    b.textContent = t;
    b.setAttribute("aria-pressed", String(t === state.tag));
    b.addEventListener("click", () => {
      state.tag = t;
      buildChips();
      renderMasonry();
    });
    chipWrap.appendChild(b);
  });
}

function matches(w){
  const okTag = state.tag === "All" || (w.tags||[]).includes(state.tag);
  if(!okTag) return false;
  if(!state.q) return true;
  const hay = `${w.title} ${w.year||""} ${w.medium||""} ${w.notes||""}`.toLowerCase();
  return hay.includes(state.q.toLowerCase());
}

function renderMasonry(){
  const el = $("#masonry");
  const items = state.works.filter(matches);
  el.innerHTML = "";
  items.forEach((w, idx) => {
    const d = document.createElement("article");
    d.className = "item";
    d.style.setProperty("--rot", `${(Math.random()*2.4 - 1.2).toFixed(2)}deg`);
    d.tabIndex = 0;
    d.setAttribute("role","button");
    d.setAttribute("aria-label", `Open ${w.title}`);
    d.innerHTML = `
      <img src="${w.thumb}" alt="${escapeHTML(w.title)}" loading="lazy">
      <div class="item__meta">
        <p class="item__title">${escapeHTML(w.title)}</p>
        <p class="item__sub">${escapeHTML([w.year, w.medium].filter(Boolean).join(" • "))}</p>
      </div>
    `;
    d.addEventListener("click", () => openLightbox(w));
    d.addEventListener("keydown", (e) => {
      if(e.key==="Enter"||e.key===" "){ e.preventDefault(); openLightbox(w); }
    });
    el.appendChild(d);
  });
  el.setAttribute("aria-label", `${items.length} works shown`);
}

function escapeHTML(s=""){ return String(s).replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c])); }

// ---------------- Lightbox ----------------
const lightbox = $("#lightbox");
function openLightbox(w){
  $("#lbImg").src = w.image;
  $("#lbTitle").textContent = w.title;
  $("#lbMeta").textContent = [w.year, w.medium, w.notes].filter(Boolean).join(" • ");
  lightbox.setAttribute("aria-hidden","false");
  document.body.style.overflow="hidden";
}
function closeModal(m){
  m.setAttribute("aria-hidden","true");
  document.body.style.overflow="";
}
document.addEventListener("click", (e) => {
  const close = e.target.closest("[data-close]");
  if(close){
    const m = e.target.closest(".modal");
    if(m) closeModal(m);
  }
});
document.addEventListener("keydown", (e) => {
  if(e.key==="Escape"){
    [lightbox, $("#emailModal")].forEach(m => {
      if(m.getAttribute("aria-hidden")==="false") closeModal(m);
    });
  }
});

// Shuffle button: re-randomize rotations
$("#shuffleBtn").addEventListener("click", () => renderMasonry());

// Search
$("#search").addEventListener("input", (e) => {
  state.q = e.target.value.trim();
  renderMasonry();
});

// Mood
$("#themeBtn").addEventListener("click", cycleMood);

// Open email modal manually
$("#openEmail").addEventListener("click", () => openEmailModal());

// ---------------- Tetris gate (3 moves to win) ----------------
const cv = $("#tetris");
const ctx = cv.getContext("2d");
const elMoves = $("#moves");
const elLines = $("#lines");
const elStatus = $("#status");

const startBtn = $("#startBtn");
const restartBtn = $("#restartBtn");

const emailModal = $("#emailModal");
const emailForm = $("#emailForm");
const emailInput = $("#email");
const magnetLink = $("#magnetLink");

const MAGNET_URL = "magnet.pdf"; // replace
const SUBMIT_ENDPOINT = "";      // optional

const W=10, H=20;
const CELL = cv.width / W;

let board, piece, running=false, moves=0, lines=0;
let last=0, drop=0, interval=520;

function resetTetris(){
  board = Array.from({length:H}, () => Array(W).fill(0));
  piece = spawn();
  running=false; moves=0; lines=0;
  elMoves.textContent = moves;
  elLines.textContent = lines;
  elStatus.textContent = "Press Start.";
  draw();
}
function spawn(){
  const m = [
    [0,0,0,0],
    [1,1,1,1],
    [0,0,0,0],
    [0,0,0,0],
  ];
  return {x:3,y:0,m};
}
function rotate(m){
  const N=m.length;
  const out = Array.from({length:N}, () => Array(N).fill(0));
  for(let y=0;y<N;y++) for(let x=0;x<N;x++) out[x][N-1-y]=m[y][x];
  return out;
}
function collide(p){
  for(let y=0;y<p.m.length;y++) for(let x=0;x<p.m[y].length;x++){
    if(!p.m[y][x]) continue;
    const bx=p.x+x, by=p.y+y;
    if(bx<0||bx>=W||by>=H) return true;
    if(by>=0 && board[by][bx]) return true;
  }
  return false;
}
function merge(p){
  for(let y=0;y<p.m.length;y++) for(let x=0;x<p.m[y].length;x++){
    if(!p.m[y][x]) continue;
    const bx=p.x+x, by=p.y+y;
    if(by>=0 && by<H && bx>=0 && bx<W) board[by][bx]=1;
  }
}
function clearLines(){
  let c=0;
  outer: for(let y=H-1;y>=0;y--){
    for(let x=0;x<W;x++) if(!board[y][x]) continue outer;
    board.splice(y,1);
    board.unshift(Array(W).fill(0));
    c++; y++;
  }
  if(c){ lines += c; elLines.textContent = lines; }
}
function lock(){
  merge(piece);
  clearLines();
  piece = spawn();
  if(collide(piece)){ running=false; elStatus.textContent="Game over. Press R."; }
}
function move(dx){
  const p={...piece, x: piece.x+dx};
  if(!collide(p)) piece.x=p.x;
}
function softDrop(){
  const p={...piece, y: piece.y+1};
  if(!collide(p)) piece.y=p.y;
  else lock();
}
function hardDrop(){
  while(!collide({...piece, y: piece.y+1})) piece.y++;
  lock();
}
function tryRotate(){
  const nm=rotate(piece.m);
  const kicks=[0,-1,1,-2,2];
  for(const k of kicks){
    const p={...piece, m:nm, x: piece.x+k};
    if(!collide(p)){ piece=p; return; }
  }
}
function incMove(){
  if(!running) return;
  moves++;
  elMoves.textContent = moves;
  if(moves>=3) win();
}
function win(){
  running=false;
  elStatus.textContent = "Unlocked. Email form opened.";
  openEmailModal();
}
function openEmailModal(){
  emailModal.setAttribute("aria-hidden","false");
  document.body.style.overflow="hidden";
  magnetLink.style.display="none";
  setTimeout(()=>emailInput.focus(), 40);
}
function drawCell(x,y,ghost=false){
  const px=x*CELL, py=y*CELL;
  const a = getComputedStyle(document.documentElement).getPropertyValue("--a").trim() || "#8affd6";
  const b = getComputedStyle(document.documentElement).getPropertyValue("--b").trim() || "#ff6bd6";
  const c = getComputedStyle(document.documentElement).getPropertyValue("--c").trim() || "#ffe66a";
  ctx.fillStyle = ghost ? "rgba(255,255,255,.35)" : "rgba(243,243,246,.86)";
  ctx.fillRect(px+2, py+2, CELL-4, CELL-4);
  // edge tint
  ctx.strokeStyle = ghost ? "rgba(255,255,255,.18)" : "rgba(0,0,0,.35)";
  ctx.strokeRect(px+2, py+2, CELL-4, CELL-4);
  // subtle chroma
  ctx.globalAlpha = ghost ? 0.08 : 0.10;
  ctx.fillStyle = a; ctx.fillRect(px+2, py+2, CELL-4, 2);
  ctx.fillStyle = b; ctx.fillRect(px+2, py+CELL-4, CELL-4, 2);
  ctx.fillStyle = c; ctx.fillRect(px+2, py+2, 2, CELL-4);
  ctx.globalAlpha = 1;
}
function drawPiece(p,ghost=false){
  for(let y=0;y<p.m.length;y++) for(let x=0;x<p.m[y].length;x++){
    if(p.m[y][x]){
      const bx=p.x+x, by=p.y+y;
      if(by>=0) drawCell(bx,by,ghost);
    }
  }
}
function draw(){
  ctx.clearRect(0,0,cv.width,cv.height);
  ctx.fillStyle="rgba(0,0,0,.22)";
  ctx.fillRect(0,0,cv.width,cv.height);
  ctx.strokeStyle="rgba(255,255,255,.06)";
  for(let x=0;x<=W;x++){ ctx.beginPath(); ctx.moveTo(x*CELL,0); ctx.lineTo(x*CELL,cv.height); ctx.stroke(); }
  for(let y=0;y<=H;y++){ ctx.beginPath(); ctx.moveTo(0,y*CELL); ctx.lineTo(cv.width,y*CELL); ctx.stroke(); }

  for(let y=0;y<H;y++) for(let x=0;x<W;x++) if(board[y][x]) drawCell(x,y,false);

  const g={...piece, y: piece.y};
  while(!collide({...g, y: g.y+1})) g.y++;
  drawPiece(g,true);
  drawPiece(piece,false);
}
function update(t=0){
  if(!running){ draw(); return; }
  const dt=t-last; last=t;
  drop += dt;
  if(drop>interval){ softDrop(); drop=0; }
  draw();
  requestAnimationFrame(update);
}
function start(){
  if(running) return;
  running=true;
  elStatus.textContent="Make 3 moves to win.";
  last=performance.now();
  drop=0;
  requestAnimationFrame(update);
}
startBtn.addEventListener("click", start);
restartBtn.addEventListener("click", resetTetris);

document.addEventListener("keydown", (e) => {
  if(e.key==="r"||e.key==="R"){ resetTetris(); return; }
  if(!running) return;
  if(e.key==="ArrowLeft"){ move(-1); incMove(); }
  else if(e.key==="ArrowRight"){ move(1); incMove(); }
  else if(e.key==="ArrowDown"){ softDrop(); incMove(); }
  else if(e.key==="ArrowUp"){ tryRotate(); incMove(); }
  else if(e.key===" "){ e.preventDefault(); hardDrop(); incMove(); }
});

emailForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  const email = emailInput.value.trim();
  if(!email) return;

  if(SUBMIT_ENDPOINT){
    try{
      const res = await fetch(SUBMIT_ENDPOINT, {
        method:"POST",
        headers:{ "Content-Type":"application/json" },
        body: JSON.stringify({ email, source:"tetris-gate" })
      });
      if(!res.ok) throw new Error("submit failed");
    }catch(err){
      alert("Could not submit right now. Please try again.");
      return;
    }
  }else{
    localStorage.setItem("denisas_email", email);
  }

  magnetLink.href = MAGNET_URL;
  magnetLink.style.display = "inline";
  magnetLink.textContent = "Download magnet";
});

// ---------------- Init ----------------
async function main(){
  initMood();
  state.data = await loadJSON("./data/site.json");
  state.works = state.data.works || [];
  renderPractice();
  buildChips();
  renderMasonry();
  resetTetris();
}
main().catch(err => {
  console.error(err);
  $("#masonry").innerHTML = `<p class="muted">Could not load data. Run a local server (see README).</p>`;
});
