# Denisas Kolomyckis — Artistic One-Pager

This is a static one-page portfolio site with:
- color mood switch (Mood button)
- animated grain canvas
- masonry works grid + lightbox
- tiny Tetris gate (3 moves to win) -> email modal -> magnet download

## Run locally
Because the site loads JSON via fetch(), run a local server:

```bash
python -m http.server 5173
```

Open:
http://localhost:5173

## Edit content
- `data/site.json`
  - artist bio/statement/practice
  - works list (titles, years, mediums, tags)
- Replace `magnet.pdf` with your real file, or update the MAGNET_URL in `script.js`.

## Email capture
By default, submitted emails are stored in browser localStorage.
To store emails for real, set `SUBMIT_ENDPOINT` in `script.js` to your backend or a service endpoint.
